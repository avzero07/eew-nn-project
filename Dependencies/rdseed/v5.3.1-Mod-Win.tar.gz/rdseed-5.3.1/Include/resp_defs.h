#ifndef PRINTDEFS_H
#define PRINTDEFS_H

static char *com_strt="#\t\t";  /* used to pad comments for alignment */
static char *fld_pref="F";             /* used as field designator prefix */

#endif
